package com.example.keisersimulator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.random.Random

data class Item(val name: String, val rarity: String, val value: Int)

private val cases = listOf(
    "Новичок" to 100,
    "Профи" to 250,
    "Неон" to 500,
    "Солярис" to 1000
)

private val itemPool = listOf(
    Item("Обычный предмет", "Обычный", 40),
    Item("Синий предмет", "Редкий", 120),
    Item("Фиолетовый предмет", "Эпический", 350),
    Item("Золотой предмет", "Легендарный", 900),
    Item("Секретный предмет", "Мифический", 2500)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { KeiserApp() }
    }
}

@Composable
fun KeiserApp() {
    var coins by remember { mutableIntStateOf(5000) }
    var selectedCase by remember { mutableStateOf(cases.first()) }
    var lastItem by remember { mutableStateOf<Item?>(null) }
    val inventory = remember { mutableStateListOf<Item>() }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF101114),
            surface = Color(0xFF181A1F),
            primary = Color(0xFF8FB7FF)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF101114),
            topBar = {
                Row(
                    Modifier.fillMaxWidth().padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("КЕЙСЕР", fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text("🪙 $coins", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Симулятор кейсов", fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Открывай кейсы за виртуальные монеты и собирай коллекцию.",
                        color = Color.LightGray
                    )
                }

                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1D24)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(
                            Modifier.fillMaxWidth().padding(18.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                selectedCase.first,
                                fontSize = 25.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text("Цена: ${selectedCase.second} 🪙", color = Color.Gray)
                            Spacer(Modifier.height(18.dp))

                            Box(
                                Modifier.size(150.dp)
                                    .background(Color(0xFF252A34), RoundedCornerShape(24.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("📦", fontSize = 64.sp)
                            }

                            Spacer(Modifier.height(18.dp))

                            Button(
                                onClick = {
                                    val price = selectedCase.second
                                    if (coins >= price) {
                                        coins -= price
                                        val item = itemPool.random()
                                        inventory.add(0, item)
                                        lastItem = item
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("ОТКРЫТЬ КЕЙС", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                item {
                    Text("Кейсы", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }

                items(cases) { c ->
                    OutlinedButton(
                        onClick = { selectedCase = c },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(c.first)
                            Text("${c.second} 🪙")
                        }
                    }
                }

                lastItem?.let { item ->
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF202631)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(16.dp)) {
                                Text("Последний дроп", fontWeight = FontWeight.Bold)
                                Text(item.name, fontSize = 21.sp)
                                Text("${item.rarity} • ${item.value} 🪙", color = Color.Gray)
                            }
                        }
                    }
                }

                item {
                    Text("Инвентарь", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }

                if (inventory.isEmpty()) {
                    item { Text("Пока пусто. Открой первый кейс!", color = Color.Gray) }
                } else {
                    items(inventory) { item ->
                        Row(
                            Modifier.fillMaxWidth()
                                .background(Color(0xFF181A1F), RoundedCornerShape(14.dp))
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("◆", fontSize = 24.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(item.name, fontWeight = FontWeight.SemiBold)
                                Text("${item.rarity} • ${item.value} 🪙", color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}